#ifndef LUA_API_H
#define LUA_API_H

#include "common.h"

void l_init(lua_State *L);

extern bool hold;

#endif // LUA_API_H
