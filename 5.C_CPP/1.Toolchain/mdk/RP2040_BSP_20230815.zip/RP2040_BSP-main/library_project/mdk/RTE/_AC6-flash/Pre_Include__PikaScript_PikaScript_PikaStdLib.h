
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'template' 
 * Target:  'AC6-flash' 
 */

#ifndef PRE_INCLUDE__PIKASCRIPT_PIKASCRIPT_PIKASTDLIB_H
#define PRE_INCLUDE__PIKASCRIPT_PIKASCRIPT_PIKASTDLIB_H

/* PikaTech.PikaScript::PikaScript:PikaScript:PikaStdLib:1.10.6 */
#include "RTE_Components.h"
#if !((defined(LV_USE_PIKASCRIPT_BINDING) && LV_USE_PIKASCRIPT_BINDING) ||  (defined(PIKA_USE_LVGL_BINDING) && PIKA_USE_LVGL_BINDING))
#   define PIKA_MODULE_PIKA_LVGL_DISABLE    1
#endif

#endif /* PRE_INCLUDE__PIKASCRIPT_PIKASCRIPT_PIKASTDLIB_H */
