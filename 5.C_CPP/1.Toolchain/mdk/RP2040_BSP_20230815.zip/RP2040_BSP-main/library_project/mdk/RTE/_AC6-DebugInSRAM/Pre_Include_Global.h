
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'template' 
 * Target:  'AC6-DebugInSRAM' 
 */

#ifndef PRE_INCLUDE_GLOBAL_H
#define PRE_INCLUDE_GLOBAL_H

/* ARM::Acceleration:Arm-2D:Core:1.1.2-dev */
#define ___ARM_2D_CFG_HEADER___
/* GorgonMeducer::Utilities:perf_counter:Core:Source:2.1.0 */
#define __PERF_COUNTER_CFG_USE_SYSTICK_WRAPPER__ 1


#endif /* PRE_INCLUDE_GLOBAL_H */
