
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'template' 
 * Target:  'BSP_Library' 
 */

#ifndef PRE_INCLUDE_GLOBAL_H
#define PRE_INCLUDE_GLOBAL_H

/* GorgonMeducer::Utilities:perf_counter:Core:Source:2.2.2 */
#define __PERF_COUNTER_CFG_USE_SYSTICK_WRAPPER__ 1


#endif /* PRE_INCLUDE_GLOBAL_H */
