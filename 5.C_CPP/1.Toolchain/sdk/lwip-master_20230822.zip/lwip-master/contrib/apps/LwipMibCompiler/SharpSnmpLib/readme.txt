See docs in src/apps/snmp/snmp_core.c.
