# BadUSB
A collection of badusb scripts that I convert for each type of device.  Some depend on local storage and some use web requests.  Exfil via discord
