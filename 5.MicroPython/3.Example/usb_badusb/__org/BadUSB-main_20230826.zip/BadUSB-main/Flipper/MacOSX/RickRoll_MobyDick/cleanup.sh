rm -rf ~/Rickroll
launchctl bootout gui/501/com.youtube.rickroll.prank
rm -rf $HOME/Library/LaunchAgents/com.youtube.rickroll.prank.plist

