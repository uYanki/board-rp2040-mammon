rm -rf /Volumes/BashBunny/payloads/switch2/*
rm -rf ~/Rickroll
launchctl bootout gui/501/com.youtube.rickroll.prank
