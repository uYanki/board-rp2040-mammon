# Payload section

### Use only with ethical reasons

### Remember to keep your PicoDucky in setup mode when adding your payload







<hr/>


# Disclaimer

## Do not use it to harm anyone or their properties