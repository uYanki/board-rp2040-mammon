# Evil-Pico-BadUSB
Raspberry Pi Pico BadUsb with some hardware upgrades.
This project has been forked from the repo in the link but i use V1.4 https://github.com/dbisu/pico-ducky

![project1](https://github.com/omerbaysoy/evil-pico-BadUSB/assets/134011706/c24eee6e-48b8-4039-9e17-8062321e50cf)
![project6](https://github.com/omerbaysoy/evil-pico-BadUSB/assets/134011706/3b36aebe-504d-4d95-8513-378ae3cba845)
![project5](https://github.com/omerbaysoy/evil-pico-BadUSB/assets/134011706/1e838bde-1078-4f69-81d5-fb8394128cb8)
![project4](https://github.com/omerbaysoy/evil-pico-BadUSB/assets/134011706/7360df40-57eb-4b7b-be27-c3794fd51025)
![project3](https://github.com/omerbaysoy/evil-pico-BadUSB/assets/134011706/ff23645a-8b7c-4d5d-a6d1-64d6c555c456)
![project2](https://github.com/omerbaysoy/evil-pico-BadUSB/assets/134011706/5d9d9f04-bd0e-46ee-a607-c4df7651447b)
